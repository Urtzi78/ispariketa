package isp;

public interface EmailReceiver {
	public String getEmail();
}
