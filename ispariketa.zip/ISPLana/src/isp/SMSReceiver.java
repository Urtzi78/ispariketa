package isp;

public interface SMSReceiver {
	public String getTelephone();
}
